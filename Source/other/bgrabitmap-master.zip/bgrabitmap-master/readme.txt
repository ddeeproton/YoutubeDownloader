List of directories:
- bgrabitmap: contains BGRABitmap library
- makedoc: contains a program to make documentation from source code
- test: contains a series of test programs and examples on how to use BGRABitmap library
